/**
   @version 1.01 2004-02-21
   @author Cay Horstmann
*/
package kr.otherpkg;
import kr.ac.kookmin.cs.*;

public class PPointTest {
     /**
      This method attempts to grow an array by allocating a
      new array and copying all elements. 
      @param a the array to grow
      @return a larger array that contains all elements of a.
      However, the returned array has type Object[], not
      the same type as a
   */
    public static void main(String args[]) {
        /**
      This method attempts to grow an array by allocating a
      new array and copying all elements. 
      @param a the array to grow
      @return a larger array that contains all elements of a.
      However, the returned array has type Object[], not
      the same type as a
   */
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}
