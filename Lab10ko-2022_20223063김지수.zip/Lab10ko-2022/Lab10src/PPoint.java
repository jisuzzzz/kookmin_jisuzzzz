/**
   @version 1.01 2004-02-21
   @author Cay Horstmann
*/
package kr.ac.kookmin.cs;
public class PPoint {
     /**
      This method attempts to grow an array by allocating a
      new array and copying all elements. 
      @param a the array to grow
      @return a larger array that contains all elements of a.
      However, the returned array has type Object[], not
      the same type as a
   */
    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    public int getX() {
        return xA;
    }
    public int getY() {
        return yA;
    }
}
